package com.cskaoyan.javase.swing.manager.stage5.model;

/**
 * 模拟学生数据源
 *
 * @since 14:09
 * @author wuguidong@cskaoyan.onaliyun.com
 */
public class StudentData {
    public static final Student[] STUDS = new Student[20];
    public static final String[] COLUMNS;

    static {
        // 初始化
        init();
        // 表格列数据
        COLUMNS = new String[]{"学号", "姓名", "性别", "学校", "专业", "年龄", "城市", "手机号", "电子邮箱"};
    }

    /**
     * 初始化数据源数据
     * @since 9:27
     * @author wuguidong@cskaoyan.onaliyun.com
     */
    private static void init() {
        // 插入学生对象
        STUDS[0] = new Student("11", "李明", "女", "北京大学", "软件工程", "18", "武汉", "13817618878", "123@qq.com");
        STUDS[1] = new Student("2", "马南山", "男", "华中师范大学", "计算机科学与技术", "27", "武汉", "13827618878", "123@qq.com");
        STUDS[2] = new Student("4", "周杰伦", "男", "中南财经政法大学", "计算机科学与技术", "16", "武汉", "13837618878", "888@qq.com");
        STUDS[3] = new Student("13", "周杰", "女", "华中科技大学", "软件工程", "22", "武汉", "13747618878", "123@qq.com");
        STUDS[4] = new Student("3", "陈奕迅", "男", "清华大学", "计算机科学与技术", "33", "武汉", "13833618878", "123@qq.com");
        STUDS[5] = new Student("5", "蓝若惜", "女", "清华大学", "计算机科学与技术", "17", "武汉", "13844328878", "222@qq.com");
        STUDS[6] = new Student("8", "苏铭", "女", "复旦大学", "软件工程", "13", "深圳", "13523281231", "555@qq.com");
        STUDS[7] = new Student("9", "罗峰", "男", "武汉大学", "机械工程", "9", "武汉", "13713137631", "123@qq.com");
        STUDS[8] = new Student("10", "萧炎", "男", "武汉大学", "土木工程", "22", "北京", "13512381293", "123@qq.com");
        STUDS[9] = new Student("18", "上官若", "女", "湖北中医药大学", "计算机科学与技术", "31", "长沙", "13712383128", "666@qq.com");
        STUDS[10] = new Student("19", "李明", "男", "郑州大学", "计算机科学与技术", "26", "南京", "13687121222", "333@qq.com");
        STUDS[11] = new Student("1", "王敏", "女", "武汉大学", "计算机科学与技术", "45", "信阳", "13587123731", "333@qq.com");
        STUDS[12] = new Student("17", "李明", "男", "中南大学", "计算机科学与技术", "36", "长沙", "13681223231", "333@qq.com");
        STUDS[13] = new Student("15", "李明", "女", "南京大学", "计算机科学与技术", "12", "石家庄", "13787113736", "333@qq.com");
        STUDS[14] = new Student("16", "石昊", "男", "武汉大学", "土木工程", "19", "武汉", "13787113736", "131@qq.com");
        STUDS[15] = new Student("6", "肖然", "女", "中南财经政法大学", "化学", "37", "长沙", "13787113736", "666@qq.com");
        STUDS[16] = new Student("20", "南宫问天", "男", "南京大学", "计算机科学与技术", "36", "长沙", "13587113736", "111@qq.com");
        STUDS[17] = new Student("7", "李逍遥", "女", "南京大学", "生物工程", "10", "北京", "13687113736", "777@qq.com");
        STUDS[18] = new Student("12", "玄烨", "女", "郑州大学", "车辆工程", "28", "呼和浩特", "13687113736", "888@qq.com");
        STUDS[19] = new Student("14", "李明", "男", "苏州大学", "制药工程", "39", "苏州", "13687113736", "999@qq.com");
    }
}
