package com.cskaoyan.javase.swing.manager.stage3.dao.impl;

import com.cskaoyan.javase.swing.manager.stage3.dao.StudentDao;
import com.cskaoyan.javase.swing.manager.stage3.model.Student;
import com.cskaoyan.javase.swing.manager.stage3.model.StudentData;

/**
 * 与学生Student相关的，所有数据处理都在该类下进行
 *
 * @author wuguidong@cskaoyan.onaliyun.com
 * @since 14:26
 */
public class StudentDaoImpl implements StudentDao {

    // 从数据源获取数据
    private Student[] STUDS = StudentData.STUDS;
    private String[] COLUMNS = StudentData.COLUMNS;

    /**
     * 数组中有很多null元素,为了避免空指针异常
     * 该方法筛选中其中非null元素构成一个新的学生数组,作为返回值
     *
     * @return com.cskaoyan.javase.swing.manager.stage2.model.Student[]
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 9:57
     */
    @Override
    public Student[] getRealStudents() {
        // 获取数据
        // 确定不为null学生元素的个数
        int count = 0;
        for (Student stu : STUDS) {
            if (stu != null) {
                count++;
            }
        }
        Student[] result = new Student[count];
        int index = 0;
        for (Student stu : STUDS) {
            if (stu != null) {
                result[index] = stu;
                index++;
            }
        }
        return result;
    }

    @Override
    public String[] getTableColumns() {
        return COLUMNS;
    }

    /**
     * 检查id是否重复,true表示id重复,false为不重复
     *
     * @param id 传入学生id
     * @return boolean true表示id重复,false为不重复
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 18:09
     */
    @Override
    public boolean checkStuIdRepeat(String id) {
        Student[] realStudents = getRealStudents();
        for (Student realStudent : realStudents) {
            if (realStudent.getStuId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 插入,由于数组长度不可改变
     * 所以逻辑是将数组中的null元素变为一个对象
     *
     * @param stu 被插入的非空学生
     * @return boolean true表示插入成功
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 14:26
     */
    @Override
    public boolean addStudent(Student stu) {
        for (int i = 0; i < STUDS.length; i++) {
            if (STUDS[i] == null) {
                STUDS[i] = stu;
                return true;
            }
        }
        return false;
    }

    /**
     * 删除一条学生信息，遍历id，若找到，设为null，返回ture，若未找到，返回false
     *
     * @param id 前端传来的要删除的id
     * @return boolean
     * @author MinjieZhang
     * @date 2023/03/17 13:56
     */
    @Override
    public boolean delStudent(String id) {
        String targetId = id;
        for (int i = 0; i < STUDS.length; i++) {
            if (targetId.equals(STUDS[i].getStuId())) {
                STUDS[i] = null;
                return true;
            }
        }
        return false;
    }

    /**
     * 根据学号，查到唯一的一条学生信息
     * @param stuId
     * @return java.lang.String[]
     * @author MinjieZhang
     * @date 2023/03/17 14:14
     */
    @Override
    public Student[] getResultByStuId(String stuId) {
        String targetId =stuId;
        Student[] result = new Student[1];

        Student[] realStudents = getRealStudents();
        for (int i = 0; i < realStudents.length; i++) {
            if (targetId.equals(realStudents[i].getStuId())) {
                result[0] = realStudents[i];
                return result;
            }
        }
        return null;
    }

    /**
     * 根据姓名，查询多条数据
     * @param name
     * @return com.cskaoyan.javase.swing.manager.stage3.model.Student[]
     * @author MinjieZhang
     * @date 2023/03/17 14:50 
     */
    @Override
    public Student[] getResultByName(String name) {
        //目标名字
        String targetName =name;
        //真实学生数组 数据库
        Student[] realStudents = getRealStudents();
        //目标姓名的个数
        int targetNamNum =getAllTargetName(name);
        //未找到
        if(targetNamNum==0){
            return null;
        }
        //代码到这里，代表找到相同姓名
        Student[] result = new Student[targetNamNum];
        int index = 0;
        for (int i = 0; i < realStudents.length; i++) {
            //找到相同名字
            if (targetName.equals(realStudents[i].getName())) {
                result[index] = realStudents[i];
            //    System.out.println(result[index]);
                index++;
            }
        }
        return result;
    }

    /**
     * 计算数据库学生数组中，有多少条目标姓名的数据
     * @param name  目标姓名
     * @return int
     * @author MinjieZhang
     * @date 2023/03/17 15:01
     */
    private int getAllTargetName(String name) {
        int count = 0;

        //真实学生数组 数据库
        Student[] realStudents = getRealStudents();

        for (int i = 0; i < realStudents.length; i++) {
            if (name.equals(realStudents[i].getName())){
                count ++;
            }
        }
        return count;
    }
}
