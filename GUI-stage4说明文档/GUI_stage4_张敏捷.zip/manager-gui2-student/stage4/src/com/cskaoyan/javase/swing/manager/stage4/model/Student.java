package com.cskaoyan.javase.swing.manager.stage4.model;

/**
 * 学生实体类
 * @since 10:00
 * @author wuguidong@cskaoyan.onaliyun.com
 */

public class Student {

    // 学号
    private String stuId;
    // 姓名
    private String name;
    // 性别
    private String gender;
    // 学校
    private String school;
    // 专业
    private String major;
    // 年龄
    private String age;
    // 城市
    private String city;
    // 电话
    private String phone;
    // 邮箱
    private String email;


    public Student() {
        super();
    }

    public Student(String stuId, String name, String gender, String school, String major, String age, String city, String phone, String email) {
        this.stuId = stuId;
        this.name = name;
        this.gender = gender;
        this.school = school;
        this.major = major;
        this.age = age;
        this.city = city;
        this.phone = phone;
        this.email = email;
    }

    @Override
    public String toString() {
        return
                "stuId=" + stuId +
                        ",name=" + name +
                        ",gender=" + gender +
                        ",school=" + school +
                        ",major=" + major +
                        ",age=" + age +
                        ",city=" + city +
                        ",phone=" + phone +
                        ",email=" + email ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Student student = (Student) o;

        if (stuId != null ? !stuId.equals(student.stuId) : student.stuId != null) return false;
        if (name != null ? !name.equals(student.name) : student.name != null) return false;
        if (gender != null ? !gender.equals(student.gender) : student.gender != null) return false;
        if (school != null ? !school.equals(student.school) : student.school != null) return false;
        if (major != null ? !major.equals(student.major) : student.major != null) return false;
        if (age != null ? !age.equals(student.age) : student.age != null) return false;
        if (city != null ? !city.equals(student.city) : student.city != null) return false;
        if (phone != null ? !phone.equals(student.phone) : student.phone != null) return false;
        return email != null ? email.equals(student.email) : student.email == null;
    }

    @Override
    public int hashCode() {
        int result = stuId != null ? stuId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (gender != null ? gender.hashCode() : 0);
        result = 31 * result + (school != null ? school.hashCode() : 0);
        result = 31 * result + (major != null ? major.hashCode() : 0);
        result = 31 * result + (age != null ? age.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        return result;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
