package com.cskaoyan.javase.swing.manager.stage4.dao.impl;

import com.cskaoyan.javase.swing.manager.stage4.dao.StudentDao;
import com.cskaoyan.javase.swing.manager.stage4.model.Student;
import com.cskaoyan.javase.swing.manager.stage4.model.StudentData;

/**
 * 与学生Student相关的，所有数据处理都在该类下进行
 *
 * @author wuguidong@cskaoyan.onaliyun.com
 * @since 14:26
 */
public class StudentDaoImpl implements StudentDao {

    // 从数据源获取数据
    private Student[] STUDS = StudentData.STUDS;
    private String[] COLUMNS = StudentData.COLUMNS;

    /**
     * 数组中有很多null元素,为了避免空指针异常
     * 该方法筛选中其中非null元素构成一个新的学生数组,作为返回值
     *
     * @return com.cskaoyan.javase.swing.manager.stage2.model.Student[]
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 9:57
     */
    @Override
    public Student[] getRealStudents() {
        // 获取数据
        // 确定不为null学生元素的个数
        int count = 0;
        for (Student stu : STUDS) {
            if (stu != null) {
                count++;
            }
        }
        Student[] result = new Student[count];
        int index = 0;
        for (Student stu : STUDS) {
            if (stu != null) {
                result[index] = stu;
                index++;
            }
        }
        return result;
    }

    /**
     * 检查id是否重复,true表示id重复,false为不重复
     *
     * @param id 传入学生id
     * @return boolean true表示id重复,false为不重复
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 18:09
     */
    @Override
    public boolean checkStuIdRepeat(String id) {
        Student[] realStudents = getRealStudents();
        for (Student realStudent : realStudents) {
            if (realStudent.getStuId().equals(id)) {
                return true;
            }
        }
        return false;
    }


    @Override
    public String[] getTableColumns() {
        return COLUMNS;
    }

    /**
     * 插入,由于数组长度不可改变
     * 所以逻辑是将数组中的null元素变为一个对象
     *
     * @param stu 被插入的非空学生
     * @return boolean true表示插入成功
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 14:26
     */
    @Override
    public boolean addStudent(Student stu) {
        for (int i = 0; i < STUDS.length; i++) {
            if (STUDS[i] == null) {
                STUDS[i] = stu;
                return true;
            }
        }
        return false;
    }

    /**
     * 数组无法真正删除一个存储单元,所以将对象置为null
     * 将这个逻辑视为删除一条学生信息
     * 删除成功(对象置为null成功)就返回true
     * 构造就返回false
     *
     * @param id 学生id
     * @return boolean
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 10:04
     */
    @Override
    public boolean delStudent(String id) {
        for (int i = 0; i < STUDS.length; i++) {
            // 为了避免空指针异常,排除null
            if (STUDS[i] == null) {
                continue;
            }
            if (id.equals(STUDS[i].getStuId())) {
                STUDS[i] = null;
                // 删除成功
                return true;
            }
        }
        return false;
    }

    /**
     * 通过id查询学生,如果没查到就返回null
     *
     * @param stuId 检索目标id
     * @return com.cskaoyan.javase.swing.manager.stage5.model.Student
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 20:43
     */
    @Override
    public Student getStudentByStuId(String stuId) {
        // 去除null,避免空指针异常
        Student[] realStudents = getRealStudents();
        for (Student stu : realStudents) {
            if (stu.getStuId().equals(stuId)) {
                return stu;
            }
        }
        return null;
    }

    /**
     * 通过name查询学生,如果没查到就返回null。由于查到的学生记录可能不止一条，所以需要一个学生数组存放
     *
     * @param name 检索目标name
     * @return com.cskaoyan.javase.swing.manager.stage5.model.Student[]
     * @author wuguidong@cskaoyan.onaliyun.com
     * @since 12:38
     */
    @Override
    public Student[] getStudentByName(String name) {
        // 去除null,避免空指针异常
        Student[] realStudents = getRealStudents();
        int count = 0;
        for (Student stu : realStudents) {
            if (stu.getName().equals(name)) {
                count++;
            }
        }
        if (count == 0) {
            // 未找到学生
            return null;
        }
        // 创建对应长度的学生数组
        Student[] result = new Student[count];
        // 遍历并赋值
        int index = 0;
        for (Student stu : realStudents) {
            if (stu.getName().equals(name)) {
                result[index] = stu;
                index++;
            }
        }
        return result;
    }

    /**
     * 更新表格某一行某一列，即某个单元格的具体数据   更新成功返回true，否则返回false
     *
     * @param targetStuId 目标id
     * @param targetCol   目标列
     * @param newValue    目标值
     * @return boolean
     * @author MinjieZhang
     * @date 2023/03/18 13:35
     */
    @Override
    public boolean updateCellByStuId(String targetStuId, int targetCol, String newValue) {

        for (int i = 0; i < STUDS.length; i++) {

            //判空
            if (STUDS[i] == null) {
                continue;
            }
            if (targetStuId.equals(STUDS[i].getStuId())) {
                //找到要修改的对象
                switch (targetCol) {
                    case 1:
//                        if (STUDS[i].getName().equals(newValue)){
//                            //名字相同时
//                            return false;
//                        }
                        STUDS[i].setName(newValue);
                        return true;
                    case 2:
//                        if (STUDS[i].getGender().equals(newValue)){
//                            //性别相同时
//                            return false;
//                        }
                        STUDS[i].setGender(newValue);
                        return true;
                    case 3:
//                        if (STUDS[i].getSchool().equals(newValue)){
//                            //学校相同时
//                            return false;
//                        }
                        STUDS[i].setSchool(newValue);
                        return true;
                    case 4:
//                        if (STUDS[i].getMajor().equals(newValue)){
//                            //专业相同时
//                            return false;
//                        }
                        STUDS[i].setMajor(newValue);
                        return true;
                    case 5:
//                        if (STUDS[i].getAge().equals(newValue)){
//                            //年龄相同时
//                            return false;
//                        }
                        STUDS[i].setAge(newValue);
                        return true;
                    case 6:
//                        if (STUDS[i].getCity().equals(newValue)){
//                            //城市相同时
//                            return false;
//                        }
                        STUDS[i].setCity(newValue);
                        return true;
                    case 7:
//                        if (STUDS[i].getPhone().equals(newValue)){
//                            //手机相同时
//                            return false;
//                        }
                        STUDS[i].setPhone(newValue);
                        return true;
                    case 8:
//                        if (STUDS[i].getEmail().equals(newValue)){
//                            //邮箱相同时
//                            return false;
//                        }
                        STUDS[i].setEmail(newValue);
                        return true;
                }

            }
        }
        return false;
    }

    /**
     * 通过id直接修改一条学生信息,相当于用一个对象替换原先的对象 ,方法返回一个int状态值表示结果
     * 0: 表示成功修改
     * 1: 表示数据完全一致,禁止修改
     * 2: 未找到该学生,修改失败
     *
     * @param targetStuId 目标id
     * @param stu         新的学生对象
     * @return int
     * @author MinjieZhang
     * @date 2023/03/18 14:06
     */
    @Override
    public int updateStudentByStuId(String targetStuId, Student stu) {
        for (int i = 0; i < STUDS.length; i++) {
            //判空,并跳过
            if (STUDS[i]==null){
                continue;
            }
            //找到要修改的对象
            if (targetStuId.equals(STUDS[i].getStuId())){
                if (stu.equals(STUDS[i])){
                    //表示数据完全一致,禁止修改
                    return 1;
                }
                //到这里表示数据中有不一样的地方,赋值,修改成功
                STUDS[i] = stu;
                return 0;
            }
        }
        return 2;
    }



}


