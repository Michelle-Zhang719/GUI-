package com.cskaoyan.javase.swing.manager.stage1.dao;

import com.cskaoyan.javase.swing.manager.stage1.model.User;
import com.cskaoyan.javase.swing.manager.stage1.model.UserData;

/**
 * 与管理员用户相关的，所有数据处理都在该类下进行
 *
 * @author wuguidong@cskaoyan.onaliyun.com
 * @since 19:36
 */
public class UserDao {

    // 从数据源获取数据
    private User[] users = UserData.USERS;

    /**
     * Description: 寻找用户名，若相同，则返回true 不同返回false
     *
     * @param user 装有前端输入的用户名和密码的对象
     * @return boolean
     * @author: MinjieZhang
     * @date: 2023/3/11 22:15
     */
    public boolean findUserName(User user) {
        for (int i = 0; i < users.length; i++) {
            if (users[i] == null) {
                continue;
            }
            if (user.getUsername().equals(users[i].getUsername()) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Description: 验证密码和账户是否同时相同 相同返回true 不同返回false
     *
     * @param user 装有前端输入的用户名和密码的对象
     * @return boolean
     * @author: MinjieZhang
     * @date: 2023/3/11 22:18
     */
    public boolean verifySame(User user) {
        for (int i = 0; i < users.length; i++) {
            if (users[i] == null) {
                continue;
            }
            if ((user.getUsername().equals(users[i].getUsername()) )&& (user.getPassword().equals(users[i].getPassword()) )) {
                return true;
            }
        }
        return false;
    }
}
