package com.cskaoyan.javase.swing.manager.stage2.dao;

import com.cskaoyan.javase.swing.manager.stage2.model.Student;

/**
 * 与Student学生数据相关的，数据操作的接口
 *
 * @since 14:21
 * @author wuguidong@cskaoyan.onaliyun.com
 */
public interface StudentDao {

    // 获取表格列数据
    String[] getTableColumns();

    //获取学生信息
    String[][] getTableStudent();

    //得到真实学生对象的个数
    Student[] getRealStudent();

    // 插入一条学生信息
    boolean addStudent(Student stu);
}
