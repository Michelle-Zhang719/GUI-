package com.cskaoyan.javase.swing.manager.stage2.dao.impl;

import com.cskaoyan.javase.swing.manager.stage2.dao.StudentDao;
import com.cskaoyan.javase.swing.manager.stage2.model.Student;
import com.cskaoyan.javase.swing.manager.stage2.model.StudentData;

/**
 * 与学生Student相关的，所有数据处理都在该类下进行
 *
 * @since 14:26
 * @author wuguidong@cskaoyan.onaliyun.com
 */
public class StudentDaoImpl implements StudentDao {

    // 从数据源获取数据
    private Student[] STUDS = StudentData.STUDS;
    private String[] COLUMNS = StudentData.COLUMNS;

    @Override
    public String[] getTableColumns() {
        return COLUMNS;
    }
    /**
     * 得到真实学生的信息 并封装为二维数组
     * @return java.lang.String[]
     * @author MinjieZhang
     * @date 2023/03/16 22:30
     */
    @Override
    public String[][] getTableStudent() {
        //所有真实存在的一维数组
        Student[] realStudent = getRealStudent();

        //要填满的二维数组
        String[][] realStu = new String[realStudent.length][];

        for (int i = 0; i < realStudent.length; i++) {
            Student aStu = realStudent[i];
            realStu[i]=new String[]{aStu.getStuId(),aStu.getName(),aStu.getGender(),aStu.getSchool(),
                    aStu.getMajor(),aStu.getAge(),aStu.getCity(),aStu.getPhone(),aStu.getEmail()};
        }

        return  realStu;
    }

    /**
     * 得到真实学生对象的个数,并排除数组中为null的元素
     * @return int
     * @author MinjieZhang
     * @date 2023/03/16 22:25 
     */
    @Override
    public Student[] getRealStudent() {
        int count =0;
        for (int i = 0; i < STUDS.length; i++) {
            if (STUDS[i]==null){
                continue;
            }
            count++;
        }

        Student[] result = new Student[count];
        int index = 0;
        for (Student student : STUDS) {
            if (student!=null){
                result[index]=student;

            }
            index++;
        }
        return result;
    }

    /**
     * 插入一条学生信息，找到数组中的null元素，然后赋值
     * @param stu
     * @return boolean
     * @author MinjieZhang
     * @date 2023/03/17 10:15
     */
    @Override
    public boolean addStudent(Student stu) {
        for (int i = 0; i < STUDS.length; i++) {
            if (STUDS[i]!=null){
                continue;
            }
            STUDS[i]=stu;
            return true;
        }
        return false;
    }
}
